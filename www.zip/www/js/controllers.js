angular.module('starter.controllers', [])

.controller('SignInCtrl', function($scope, $state, $timeout, $ionicLoading, session) {
  $scope.signIn = function(user) {
    $ionicLoading.show();
    $timeout(function() {
      console.log('Sign-In', user);
      session.customerId = user.id;
      $ionicLoading.hide();
      $state.go('tab.dash');
    }, 600);
  };
})

.controller('DashCtrl', function($scope, $ionicLoading, api, session) {

  $scope.showPosition = function(position) {
    var request = {};
    $scope.crime = {}; 
    $scope.accident = {};

    request.id = session.customerId;
    request.latitude = position.coords.latitude;
    request.longitude = position.coords.longitude;
    
    request.package = "crime";

    api.assessment(request).then(function(response){
      session.crime.riskSolution = parseInt(response);
      $scope.$broadcast('scroll.refreshComplete');
      $ionicLoading.hide();
      $scope.crime = session.crime;
    });

    request.package = "accident";

    api.assessment(request).then(function(response){
      session.accident.riskSolution = parseInt(response);
      $scope.$broadcast('scroll.refreshComplete');
      $ionicLoading.hide();
      $scope.accident = session.accident;
    });

  };

  $scope.getPosition = function() {
    navigator.geolocation.getCurrentPosition($scope.showPosition);  
  };

  $ionicLoading.show();
  $scope.getPosition();

})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('PackageCrimeCtrl', function($scope, $state, $stateParams, $timeout, $ionicLoading, api, session, Chats) {
  $scope.crime = session.crime || {};
  $scope.goNext = function() {
    session.crime.selectedSolution = $scope.crime.selectedSolution;
    $state.go("tab.terms-conditions", {"package": "crime"})
  };
})

.controller('TermsCtrl', function($scope, $stateParams, $state, session) {
  $scope.package = session.crime || {};
  $scope.goNext = function() {
    session.crime.currentSolution = session.crime.selectedSolution;
    $state.go("tab.confirm-purchase", {"package": "crime"})
  };
})

.controller('ForecastCtrl', function($scope, $stateParams, $state, session) {
  $scope.plans = session.travel.plans();
  $scope.goNext = function() {
    $state.go("tab.confirm-purchase", {"package": "travel"})
  };
})

.controller('TravelCtrl', function($scope, $stateParams, $state, session) {
  $scope.plans = session.travel.plans();
  $scope.goNext = function() {
    $state.go("tab.confirm-purchase", {"package": "travel"})
  };
})

.controller('TravelAddCtrl', function($scope, $stateParams, $state, session) {
  $scope.plans = session.travel.plans();
  $scope.goNext = function() {
    $state.go("tab.confirm-purchase", {"package": "travel"})
  };
})

.controller('ConfirmPurchaseCtrl', function($scope, $stateParams, $state, session) {
  $scope.package = session.crime || {};
  $scope.gotoDash = function() {
    $state.go('tab.dash');
  };
  //$scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableTracking: true
  };
});
